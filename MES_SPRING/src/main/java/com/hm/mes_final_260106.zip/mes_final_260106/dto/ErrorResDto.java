package com.hm.mes_final_260106.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter @AllArgsConstructor
public class ErrorResDto {
    private String code;
    private String message;
}
///1111111111