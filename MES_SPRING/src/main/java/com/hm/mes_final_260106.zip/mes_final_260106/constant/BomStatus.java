package com.hm.mes_final_260106.constant;

public enum BomStatus {
    ACTIVE,
    OBSOLETE
}
