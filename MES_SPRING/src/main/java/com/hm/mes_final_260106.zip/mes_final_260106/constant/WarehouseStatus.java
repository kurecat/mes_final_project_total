package com.hm.mes_final_260106.constant;

public enum WarehouseStatus {
    AVAILABLE,
    FULL
}
