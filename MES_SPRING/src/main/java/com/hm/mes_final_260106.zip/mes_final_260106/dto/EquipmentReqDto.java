package com.hm.mes_final_260106.dto;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class EquipmentReqDto {
    private String code;
    private String name;
    private String type;
    private String status;
    private String lotId;
    private Integer uph;
    private Integer temperature;
    private String param;
}
///1111111111