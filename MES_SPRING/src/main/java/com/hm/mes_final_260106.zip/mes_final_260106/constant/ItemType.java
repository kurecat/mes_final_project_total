package com.hm.mes_final_260106.constant;

public enum ItemType {
    RAW_MATERIAL,
    SEMI_FINISHED,
    FINISHED_GOOD,
    PACKAGING,
    CONSUMABLE,
    PHANTOM,
    ALTERNATIVE
}
