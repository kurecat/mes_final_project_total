package com.hm.mes_final_260106.dto;

import java.time.LocalDateTime;

public class MachineStatusDto {
    public Long MachineId;
    public int Temperature;
    public LocalDateTime Timestamp;
}
///1111111111