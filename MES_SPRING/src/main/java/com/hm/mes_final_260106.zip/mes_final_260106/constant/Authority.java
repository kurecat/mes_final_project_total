package com.hm.mes_final_260106.constant;

public enum Authority {
    ROLE_OPERATOR, // 현장 작업자 ( 생산 보고 )
    ROLE_ADMIN, // 관리자 ( 작접 지시, 자재 관리 )

}
