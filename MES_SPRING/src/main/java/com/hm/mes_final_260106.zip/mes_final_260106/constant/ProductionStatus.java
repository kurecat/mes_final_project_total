package com.hm.mes_final_260106.constant;

public enum ProductionStatus {
    RUN,
    DONE,
    FAIL
}

