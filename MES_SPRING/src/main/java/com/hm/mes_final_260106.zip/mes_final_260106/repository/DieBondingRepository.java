package com.hm.mes_final_260106.repository;

import com.hm.mes_final_260106.entity.DieBonding;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DieBondingRepository extends JpaRepository<DieBonding, Long> {
}