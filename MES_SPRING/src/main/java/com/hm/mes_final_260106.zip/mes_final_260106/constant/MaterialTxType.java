package com.hm.mes_final_260106.constant;


public enum MaterialTxType {
    INBOUND,   // 입고
    OUTBOUND,   // 불출
}
