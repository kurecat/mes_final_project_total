package com.hm.mes_final_260106.repository;

import com.hm.mes_final_260106.entity.Molding;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MoldingRepository extends JpaRepository<Molding, Long> {
}
